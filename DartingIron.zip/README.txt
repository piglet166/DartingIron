Mirror Shades

Stephan Jenkins - Game Design
Cody Kath - Animiation
Lorena Perez - Production
Paul Jones - Programming

Use the S and D keys to move.  W to jump.

The LMB will shoot a line that will either drag an enemy to the player, or drag the player
to a block or tall enemy.

You can use momentum to launch yourself over a block by jumping first, and then shooting a block

You can also use this trick to go horizontally but you must be in mid air first.

There are no lives, so the player will have many chances to figure each level out.